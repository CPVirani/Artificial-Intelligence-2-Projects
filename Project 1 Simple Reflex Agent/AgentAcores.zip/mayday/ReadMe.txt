Instructions for running the code:-

1. Compile WorldAplication.java:- javac WorldApplication.java
2. Execute WorldApplication for 50000 iterations:- java WorldApplication -t 50000 -a false