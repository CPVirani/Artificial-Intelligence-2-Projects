public class qTableConfig {

    static final int PITREWARD = -1;
    static final int WUMPUSREWARD = -1;
    static final int GOLDREWARD = 1;
    static final int BUMPREWARD = -1;

    static final double PROBABILITY = 0.5;

    static final double LEARNINGRATE = 0.5;
    static final double DISCOUNTFACTOR = 0.8;

    static final int ITERATIONS = 1000;

    static final double MAXACTIONSCORE = -1;
    static final String[] MOVE = {"LEFT", "RIGHT", "UP", "DOWN"};

}



